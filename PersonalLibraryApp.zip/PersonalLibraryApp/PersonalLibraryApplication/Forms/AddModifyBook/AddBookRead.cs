﻿using PersonalLibraryApplication.Models;

namespace PersonalLibraryApplication.Forms.AddModifyBook
{
    internal class AddBookRead
    {
        public AddBookRead()
        {
        }

        public bool AddBook { get; set; }
        public OwnedBooks Book { get; set; }
    }
}